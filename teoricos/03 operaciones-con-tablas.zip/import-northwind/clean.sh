#!/bin/sh

agens -f clean.sql postgres
